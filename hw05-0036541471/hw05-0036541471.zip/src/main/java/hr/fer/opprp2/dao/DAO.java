package hr.fer.opprp2.dao;

import hr.fer.opprp2.model.BlogEntry;
import hr.fer.opprp2.model.BlogUser;

import java.util.List;

public interface DAO {

    BlogEntry getBlogEntry(Long id) throws DAOException;

    BlogUser getBlogUser(Long id) throws DAOException;

    BlogUser getBlogUserByNick(String nick) throws DAOException;

    List<BlogUser> getBlogUsers() throws DAOException;
}