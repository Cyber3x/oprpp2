package hr.fer.oprpp2.servlets.glasanje;

public record GlasanjeEntry(String id, String bandName, String youtubeLink) {
}
