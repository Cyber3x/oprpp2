package hr.fer.zemris.java.custom.scripting.lexer;

public class SmartScriptLexerException extends RuntimeException{
    public SmartScriptLexerException() {
        super();
    }

    public SmartScriptLexerException(String message) {
        super(message);
    }
}
