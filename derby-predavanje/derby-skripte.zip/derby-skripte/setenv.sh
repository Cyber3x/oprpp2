# Podesite stazu gdje je instaliran derby
DERBY_INSTALL=/home/marcupic/bin/java-apps/apache-derby/db-derby-10.15.2.0-bin
# Podesite putanju do direktorija u kojem ce nastajati sve baze podataka
DERBY_DATABASES=/home/marcupic/tmp/derby-baze

