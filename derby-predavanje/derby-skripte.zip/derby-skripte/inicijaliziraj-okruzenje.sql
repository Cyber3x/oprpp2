connect 'jdbc:derby://localhost:1527/credentialsDB;user=sa;password=sapwd22;create=true';
disconnect;
